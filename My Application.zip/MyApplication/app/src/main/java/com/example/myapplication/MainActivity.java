package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.EditText;
import android.view.View;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;import android.widget.ImageView;import android.graphics.Bitmap;
public class MainActivity extends AppCompatActivity {

    private Spinner sp;//第一個下拉選單
    private Spinner sp2;//第二個下拉選單
    private Spinner sp3;//第三個下拉選單
    private Spinner sp4;
    private Spinner sp5;
    private Spinner sp6;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        RadioButton boys = (RadioButton) findViewById(R.id.single);
        RadioButton girls = (RadioButton) findViewById(R.id.double2);
        boys.setOnCheckedChangeListener(mOnCheckedChangeListener);
        girls.setOnCheckedChangeListener(mOnCheckedChangeListener);

        Spinner spinner = (Spinner)findViewById(R.id.sp);
        final String[] number = {"1", "2", "3", "4", "5"};
        ArrayAdapter<String> TList = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item, number);
        spinner.setAdapter(TList);

        Spinner sp2= (Spinner)findViewById(R.id.sp2);
        final String[] start = {"南港", "台北", "板橋", "桃園", "新竹","苗栗","台中","彰化","雲林","嘉義","台南","左營","高雄"};
        ArrayAdapter<String> sList = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item, start);
        sp2.setAdapter(sList);

        Spinner sp3= (Spinner)findViewById(R.id.sp3);
        final String[] end = {"南港", "台北", "板橋", "桃園", "新竹","苗栗","台中","彰化","雲林","嘉義","台南","左營","高雄"};
        ArrayAdapter<String> eList = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item, end);
        sp3.setAdapter(eList);

        Spinner sp4= (Spinner)findViewById(R.id.sp4);
        final String[] date = {"2019/12/1【日】", "2019/12/2【一】", "2019/12/3【二】", "2019/12/4【三】", "2019/12/5【四】","2019/12/6【五】","2019/12/7【六】","2019/12/8【日】"};
        ArrayAdapter<String> dList = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item, date);
        sp4.setAdapter(dList);

        Spinner sp5= (Spinner)findViewById(R.id.sp5);
        final String[] stime = {"01:00", "02:00", "03:00", "04:00", "05:00","06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"};
        ArrayAdapter<String> stList = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item, stime);
        sp5.setAdapter(stList);
        Spinner sp6= (Spinner)findViewById(R.id.sp6);
        final String[] etime = {"01:00", "02:00", "03:00", "04:00", "05:00","06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"};
        ArrayAdapter<String> etList = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item, etime);
        sp6.setAdapter(etList);




    }
    public void genCode(View view) {
        ImageView ivCode = (ImageView) findViewById(R.id.ivCode);
        EditText etContent = (EditText) findViewById(R.id.etContent);
        BarcodeEncoder encoder = new BarcodeEncoder();
        try {
            Bitmap bit = encoder.encodeBitmap(etContent.getText().toString(), BarcodeFormat.QR_CODE,
                    250, 250);
            ivCode.setImageBitmap(bit);
        } catch (WriterException e) {
            e.printStackTrace();
        }

    }



    private CompoundButton.OnCheckedChangeListener mOnCheckedChangeListener = new CompoundButton.OnCheckedChangeListener() {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            switch (buttonView.getId()) {
                case R.id.single:
                    Toast.makeText(MainActivity.this, "你選擇單程票", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.double2:
                    Toast.makeText(MainActivity.this, "你選擇來回票", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };


}
